package contactservice;

import java.util.HashMap;
import java.util.Map;

public class ContactService {
    private final Map<String, Contact> contacts = new HashMap<String, Contact>(); // FIXED for Java 8

    // Add Contact
    public void addContact(Contact contact) {
        if (contact == null || contacts.containsKey(contact.getContactID())) {
            throw new IllegalArgumentException("Contact ID already exists or is null");
        }
        contacts.put(contact.getContactID(), contact);
    }

    // Delete Contact
    public void deleteContact(String contactID) {
        if (!contacts.containsKey(contactID)) {
            throw new IllegalArgumentException("Contact not found");
        }
        contacts.remove(contactID);
    }

    // Update First Name
    public void updateFirstName(String contactID, String firstName) {
        if (!contacts.containsKey(contactID)) {
            throw new IllegalArgumentException("Contact not found");
        }
        contacts.get(contactID).setFirstName(firstName);
    }

    // Update Last Name
    public void updateLastName(String contactID, String lastName) {
        if (!contacts.containsKey(contactID)) {
            throw new IllegalArgumentException("Contact not found");
        }
        contacts.get(contactID).setLastName(lastName);
    }

    // Update Phone
    public void updatePhone(String contactID, String phone) {
        if (!contacts.containsKey(contactID)) {
            throw new IllegalArgumentException("Contact not found");
        }
        contacts.get(contactID).setPhone(phone);
    }

    // Update Address
    public void updateAddress(String contactID, String address) {
        if (!contacts.containsKey(contactID)) {
            throw new IllegalArgumentException("Contact not found");
        }
        contacts.get(contactID).setAddress(address);
    }

    // Retrieve Contact (for testing purposes)
    public Contact getContact(String contactID) {
        return contacts.get(contactID);
    }
}
