package contactservice.test;

import static org.junit.Assert.*; 
import org.junit.Test;
import contactservice.Contact;

public class ContactTest {

    // Test creating a valid contact and checking all values are correctly stored
    @Test
    public void testCreateContactSuccess() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        assertEquals("John", contact.getFirstName());
        assertEquals("Doe", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Main St", contact.getAddress());
    }

    // Test creating a contact with a null ID, which should fail and throw an exception
    @Test
    public void testCreateContactWithNullIDFails() {
        try {
            new Contact(null, "John", "Doe", "1234567890", "123 Main St");
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertEquals("Invalid contact ID", e.getMessage());
        }
    }
}
