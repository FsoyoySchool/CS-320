package contactservice.test;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import contactservice.Contact;
import contactservice.ContactService;

public class ContactServiceTest {
    private ContactService contactService;

    // Set up a new ContactService before each test
    @Before
    public void setUp() {
        contactService = new ContactService();
    }

    // Test adding a contact and confirming it is stored correctly
    @Test
    public void testAddContactSuccess() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        assertEquals(contact, contactService.getContact("12345"));
    }

    // Test deleting a contact and confirming it is removed from the service
    @Test
    public void testDeleteContactSuccess() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        contactService.deleteContact("12345");
        assertNull(contactService.getContact("12345"));
    }
}
